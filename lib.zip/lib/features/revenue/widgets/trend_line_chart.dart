import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

class TrendLineChart extends StatelessWidget {
  final List<double> values;
  final List<String> labels;

  const TrendLineChart({
    super.key,
    required this.values,
    required this.labels,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 320,
      child: LineChart(
        LineChartData(
          minX: 0,
          maxX: values.length - 1,
          minY: 0,
          maxY: (values.reduce((a, b) => a > b ? a : b) * 1.2),

          borderData: FlBorderData(show: false),

          gridData: FlGridData(
            show: true,
            drawVerticalLine: false,
          ),

          titlesData: FlTitlesData(
            topTitles:
                const AxisTitles(sideTitles: SideTitles(showTitles: false)),
            rightTitles:
                const AxisTitles(sideTitles: SideTitles(showTitles: false)),

            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                getTitlesWidget: (value, meta) {
                  final index = value.toInt();

                  if (index >= labels.length) {
                    return const SizedBox();
                  }

                  return Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(
                      labels[index],
                      style: const TextStyle(fontSize: 12),
                    ),
                  );
                },
              ),
            ),

            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                reservedSize: 45,
                showTitles: true,
                getTitlesWidget: (value, meta) {
                  return Text(
                    "${(value / 1000).toStringAsFixed(0)}k",
                    style: const TextStyle(fontSize: 11),
                  );
                },
              ),
            ),
          ),

          lineBarsData: [
            LineChartBarData(
              spots: List.generate(
                values.length,
                (index) => FlSpot(
                  index.toDouble(),
                  values[index],
                ),
              ),

              isCurved: true,

              color: Colors.blue,

              barWidth: 4,

              dotData: const FlDotData(show: true),

              belowBarData: BarAreaData(
                show: true,
                color: Colors.blue.withOpacity(.12),
              ),
            ),
          ),
        ),
      ),
    );
  }
}