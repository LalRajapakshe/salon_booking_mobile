// Customer timeline widget
