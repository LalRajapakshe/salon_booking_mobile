// Customer stats card widget
