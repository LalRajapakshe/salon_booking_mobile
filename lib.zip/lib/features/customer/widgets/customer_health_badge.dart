// Customer health badge widget
