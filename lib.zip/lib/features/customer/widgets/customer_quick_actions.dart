// Customer quick actions widget
