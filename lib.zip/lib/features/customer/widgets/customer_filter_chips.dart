// Customer filter chips widget
