// Customer header widget
