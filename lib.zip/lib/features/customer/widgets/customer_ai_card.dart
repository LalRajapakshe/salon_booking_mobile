// Customer AI card widget
