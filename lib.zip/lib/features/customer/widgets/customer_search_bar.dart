// Customer search bar widget
