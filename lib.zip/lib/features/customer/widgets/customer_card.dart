// Customer card widget
