// Section title widget
